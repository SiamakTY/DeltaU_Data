%% Modified Peak Concrete Strain Estimation for RC Structural Walls
% This script predicts the modified peak concrete compressive strain 
% ($\epsilon_{0c}^m$) of RC structural walls using their geometrical, 
% mechanical, and loading data. The predicted strain value is then supplied
% to the accompanying OpenSees (Tcl) finite element model as a calibration 
% parameter, enabling more accurate estimation of wall displacement 
% capacity and failure.
% 
% *Background:*
% 
% This script accompanies a finite element model that simulates the 
% response of RC structural walls under quasi-static lateral loads. The FE 
% model is developed in the Tcl programming language and is executable in 
% the OpenSees framework. The modified peak concrete strain 
% ($\epsilon_{0c}^m$) predicted by this script contributes to more accurate 
% estimations of displacement capacity and failure point of structural 
% walls by the FE model. 
% 
% *This script uses two pre-trained Simple Weighted Ensemble Models to 
% predict the modified peak concrete strain of untested walls WITHOUT or 
% WITH boundary elements. To compare the performance of different ML models
% , estimates by the Ensemble Models and non-zero-weighted single ML models
% are printed on screen.*
% 
% *Input Data:*
% 
% 1) Features.csv (A CSV file including the input parameters of the unseen 
% data).
% 
% 2) Pre-trained single ML models (e.g., \GPR\chosen.mat)
% 
% 3) Weights of the pre-trained single ML models for the Ensemble model 
% (e.g., \GPR\weight.txt)
% 
% 4) Support files for scaling the feature set, as read from Features.csv, 
% and decentering the outputs. These files, including meanY.txt, 
% XtrainMax.txt & XtrainMin.txt, are stored in the supportFiles 
% subdirectory. 
% 
% 5) Functions in "\codeFunctions" subdirectory.
% 
% Proper Ensemble Model for Your Structural Wall:
% 
% For walls WITHOUT confined boundary elements, the modified peak concrete 
% strain should be estimated using the 140-unit model. For walls WITH 
% boundary elements, either the 140-unit or 110-unit model can be used; 
% however, training results indicate that the 110-unit model generally 
% produces smaller estimation errors. 
%
% After the code is executed, the user will be prompted to specify whether 
% to use the 140-unit model or 110-unit model. Enter 140 for the 140-unit  
% model or 110 for the 110-unit model.
% 
% *Optimum Weights for the Single Models*
% 
% The two Ensemble Models (one for the 140- and the other one for the 
% 110-unit category) employ different optimum weight combinations for 
% single models. The optimum weights assigned to the single models were 
% determined during the training-validation process and are as follows:
% 
% 140-unit: KRR(1.0), SVR(0.9)
% 
% 110-unit: KRR(1.0), SVR(1.0), GPR(1.0)
% 
% *Output Data:*
% 
% A MATLAB table named modelsPred containing wall names, estimations by the 
% Ensemble model & non-zero-weighted single models (displayed on screen).
% 
% *Notes:*
% 
% Apart from "backTransform.m" and "MyscaleData.m", all other functions in 
% the "\codeFunctions" subdirectory are developed by:
% 
% G. Camps-Valls, L. Gomez-Chova, J. Munoz-Mari, M. Lazaro-Gredilla, J. 
% Verrelst, simpleR: A simple educational matlab toolbox for statistical 
% regression, v3.0 (3 2016). URL <http://www.uv.es/gcamps/>
% 
% In case you are facing issues with recompiling the MEX files, please
% consider installing the simpleR toolbox:
% https://github.com/IPL-UV/simpleR
%
% This script has been tested only on Windows 10/11 and macOS 
% (Apple Silicon M2) platforms, using MATLAB 2017b and 2022b. Bugs and 
% issues may occur if the script is executed on other operating systems or 
% if older MATLAB versions are used.  
%
% --------------------------------------
% 
% Code Developer: Siamak TAHAEI YAGHOUBI
% 
% DATE : 05.12.2025
%
%% Initial configurations
clear all; close all; clc

scriptPath = mfilename('fullpath'); % Full path of the script
% The directory that includes: 1) The present script and its pdf published
% version; 2) the 110-Walls subdirectory; 3) the 140-Walls subdirectory; 
% 4) codeFunctions subdirectory.
scriptDir = fileparts(scriptPath); % Extracts the dir. from the full path
scriptDir = [scriptDir,filesep]; 
% The directory containing functions used by this script 
functionsDir = [scriptDir,'codeFunctions'] ;
% Adds \codeFunctions directory to the search path
addpath(functionsDir)

% Enquiring about the Ensemble Model to work with.
prompt1 = 'Specify the Ensemble Model you want to use.'; 
prompt2 = 'Enter either 140 for the 140-unit category model';
prompt3 = 'or 110 for the 110-unit category model: \n' ;
disp(prompt1); disp(prompt2);
wallCategory = input(prompt3);
% To ensure that no invalid category name has been introduced to the code.
if (wallCategory~=140)&&(wallCategory~=110)
    criteria = 0 ;
    while criteria == 0 
        errMessage1 = ['Invalid input! The input value must be either ' ...
            '110 or 140.'] ;
        errMessage2 = 'Please enter a valid value: \ ' ;
        disp(errMessage1)
        wallCategory = input(errMessage2);
        if (wallCategory==140)||(wallCategory==110)
            criteria = 1 ;
        end
    end
end
% refDir is the directory that includes: 
% 1) The feature file (i.e., Features.csv); 
% 2) Pre-trained single model subdirectories (i.e., \KRR and \SVRR for the 
% 140-unit category, and \KRR, \SVRR & \GPR for the 110-unit category) 
% 3) Support files subdirectory (i.e., \supportFiles).
refDir = [scriptDir,[num2str(wallCategory),'-Walls'],filesep] ;
% The file including input parameters of the walls for which modified peak 
% concrete strain values must be estimated.
inputFile = 'Features.csv' ;
% Data transformation settings as applied during the model training process
transformX = 'None' ; % No data transformation for the features 
% Square root data transformation for the output data (i.e., estimated 
% modified peak concrete strain) 
transformY = 'squareRoot' ; 
powerY = 1; % A parameter used by the backTransform function

%% Importing the input parameters and some preparations for the analysis
% Importing specimen features (for example, from Features.csv).
% Expected format: 
% First row includes column headers (in text data/strings format). 
% First column includes specimen names (in text data/strings format).
% The remaining 8 columns include numerical data describing the properties 
% of walls. 
opts = detectImportOptions([refDir,inputFile]);
Xtable = readtable([refDir,inputFile], opts);
S = vartype('numeric');
% The imported numerical data (i.e., the feature set).
features = table2array(Xtable(:,S)); 
specimens = Xtable(:,1) ; % Specimen names (first column of the inputFile).

% Mean value of the training outputs for decentering
meanYfile = 'meanY.txt' ; 
% Name of the pre-trained single model (e.g., \SVR\chosen.mat)
modelName = 'chosen.mat' ;
% Maxima of the training feature set (for scaling the feature set of 
% unseen/untested walls)
XtrainMaxFile = 'XtrainMax.txt' ; 
% Minima of the training feature set (for scaling the feature set of 
% unseen/untested walls)
XtrainMinFile = 'XtrainMin.txt';
% Includes weight assigned to the pre-trained single model 
% (e.g., \SVR\weight.txt)
weightFile = 'weight.txt'; 

% Identifying the single ML models that are employed by the Ensemble model.
% Note that the employed single models depend on whether the 140- or 
% 110-unit category Ensemble model is in use for predicting the peak 
% concrete strain.
nn = 0 ;
refDirInfo = dir(refDir) ;
for ii = 1:1:size(refDirInfo,1)
    NAME = refDirInfo(ii,1).name ;
    if (strcmp(NAME,'KRR') == 1)||(strcmp(NAME,'SVR') == 1)||...
            (strcmp(NAME,'GPR') == 1)
        nn = nn + 1 ;
     % List of the single ML models that are employed by the Ensemble model
        METHODS{1,nn} = NAME ; 
        headers{1,nn} = [NAME,'_single'] ;
    end
end

% Matrix to store the estimated peak concrete strain values by the 
% pre-trained single ML models (identified as "chosen.mat" files)
Yps = zeros(size(features,1),numel(METHODS)) ; 

% Array to store weights assigned to the pre-trained single ML models
Weights = zeros(1, numel(METHODS)); 

%% Predicting the modified peak concrete strain values by single ML models
for jj = 1:1:numel(METHODS)
    % Path to single model directory
    methodDir = [refDir,char(METHODS(jj)),filesep]; 
    METHOD = char(METHODS(jj)) ;

    X = features ; % Feature set of the unseen/untested walls
    zzz = load([methodDir,modelName]) ;

    my = load([refDir,'supportFiles',filesep,meanYfile]) ; 
    XtrainMin = load([refDir,'supportFiles',filesep,XtrainMinFile]) ; 
    XtrainMax = load([refDir,'supportFiles',filesep,XtrainMaxFile]) ; 
    Weights(1,jj) = load([methodDir,weightFile]);

    % Scaling the feature set of the unseen specimens
    % Note that single ML models were trained on data scaled by the
    % $X_{scaled} = 2\frac{(X - X_{min})}{(X_{max} - X_{min})}  - 1$ 
    % formula resulting in transformed values within the [-1 1] range.                
    for rr = 1:1:8 % Eight features
       XTemp = MyscaleData(X(:,rr),XtrainMin(rr),XtrainMax(rr)); 
       X(:,rr) = XTemp;
    end
    % Predicting the peak concrete strain by the pre-trained single models
    % using the scaled feature set
    eval(['Yp = test' METHOD '(zzz.zzz,X);']); % Centered estimation
    Yp = Yp + my ; % Adding back the training output mean for decentering    
    [Yp, ~] = backTransform(Yp,Yp,transformY, powerY);
    Yps(:,jj) = Yp ;
    eval([char(headers(jj)) '  = Yp ;']) 
end

%% Predicting the modified peak concrete strain values by the Ensemble Model
% The Ensemble Model makes predictions based on estimations by the 
% single models & their assigned weights. 
% Formula: 
% $Y_{Ensemble} = \sum_{i=1}^{7} W_iY_i/\sum_{i=1}^{7} W_i$.

% The array to store the Simple Weighted Ensemble Model estimates
Ensemble= zeros(size(Yps,1),1) ; 
for jj = 1:1:numel(METHODS)
    weight = Weights(1,jj) ;
    Ensemble = Ensemble + weight*Yps(:,jj) ;
end
Ensemble = (1/sum(Weights))*Ensemble ; % Normalizing by sum of weights

%% Reporting the analysis results
% modelsPred: Wall names + Ensemble + non-zero-WEIGHTED single models. 
% modelsPred is a table for display purposes.

if (exist('KRR_single')==1)&&(exist('SVR_single')==1)&&...
        exist('GPR_single')==0 % => 140-unit category
    modelsPred = table(Ensemble , KRR_single, SVR_single) ;
elseif (exist('KRR_single')==1)&&(exist('SVR_single')==1)&&...
        exist('GPR_single')==1 % => 110-unit category
    modelsPred = table(Ensemble , KRR_single, SVR_single, GPR_single) ;
end

modelsPred = [specimens, modelsPred]; % Adding wall names to the table
% The following procedure is only for the sake of neatness. 
strver = version ; 
Rindex = strfind(strver,'R');
if isempty(Rindex) == 0
    releaseYear = strver(Rindex+1:Rindex+4) ;
    releaseYear = str2num(releaseYear);
    % dot syntaxing for tables is not compatible for before 2018 versions
    if releaseYear >= 2018 % MATLAB R2018a and later
% Replace with: 
% modelsPred{:,'Specimens'} = cellstr(modelsPred{:,'Specimens'});  
% if you are experiencing problems at this point.      
        modelsPred.Specimens = string(modelsPred.Specimens); 
    else % For pre-R2018 versions
        modelsPred{:,'Specimens'} = cellstr(modelsPred{:,'Specimens'}); 
    end
end

disp(repmat('+',1,35)) % For the sake of neatness.
disp('Peak concrete strain predictions by the ENSEMBLE & Single models: ')
disp(' ') % Empty line for the sake of neatness.
disp(modelsPred)



