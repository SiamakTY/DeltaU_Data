function Yp = mysvmpredict(~, Xtest, model)
% mysvmpredict  –  pure MATLAB replacement for libsvm's mysvmpredict
% 
% Usage (simpleR style):
%   Yp = mysvmpredict(dummy_labels, Xtest, model)
%
% Inputs:
%   ~      : unused (libsvm'de gerçek label vektörü veriliyordu, burada gerek yok)
%   Xtest  : n_test x d test feature matrix
%   model  : libsvm-style model struct with fields:
%            .SVs, .sv_coef, .rho, .Parameters
%
% Output:
%   Yp     : n_test x 1 predicted values (SVR decision function)

    % --- Extract libsvm model pieces ---
    sv     = full(model.SVs);           % Support vectors (nSV x d)
    alpha  = model.sv_coef(:);          % Coefficients (nSV x 1)
    rho    = model.rho;                 % Bias term (scalar)
    params = model.Parameters;          % [svm_type, kernel_type, degree, gamma, coef0]

    kernel_type = params(2);
    degree      = params(3);
    gamma       = params(4);
    coef0       = params(5);

    nTest = size(Xtest, 1);
    Yp    = zeros(nTest, 1);

    % --- Loop over test samples ---
    for i = 1:nTest
        x = Xtest(i,:);  % 1 x d

        % Compute kernel K(sv_j, x) for all support vectors
        switch kernel_type
            case 0  % linear: u'*v
                K = sv * x';

            case 1  % polynomial: (gamma*u'*v + coef0)^degree
                K = (gamma * (sv * x') + coef0) .^ degree;

            case 2  % RBF: exp(-gamma*||u-v||^2)
                diffs = sv - x;                 % nSV x d
                K = exp(-gamma * sum(diffs.^2, 2));

            case 3  % sigmoid: tanh(gamma*u'*v + coef0)
                K = tanh(gamma * (sv * x') + coef0);

            otherwise
                error('mysvmpredict: Unsupported kernel type (%d).', kernel_type);
        end

        % SVR decision function: sum(alpha_i * K_i) - rho
        Yp(i) = sum(alpha .* K) - rho;
    end
end
