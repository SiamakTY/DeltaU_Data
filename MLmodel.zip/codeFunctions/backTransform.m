function [Yp, Ytest] = backTransform(Yp,Ytest,transformY, powerY)
%This function back transforms the test & predicted output values for comparison
switch transformY
        case 'invsinh'
            Yp = sinh(Yp) ;
            Ytest = sinh(Ytest) ; 
        case 'log'
            Yp = exp(Yp) ;
            Ytest = exp(Ytest) ; 
        case 'reciprocal'
            Yp = 1./Yp ;
            Ytest = 1./Ytest ; 
        case 'square'
            Yp = Yp.^0.5 ;
            Ytest = Ytest.^0.5 ; 
        case 'squareRoot'
            Yp = Yp.^2 ;
            Ytest = Ytest.^2 ;  
        case 'power'
            Yp = Yp.^(1/powerY) ;
            Ytest = Ytest.^(1/powerY) ; 
        case 'logSquareRoot'
            Yp = (exp(Yp)).^2 ;
            Ytest = (exp(Ytest)).^2 ;
        case 'BoxCox'
            %lambda = input('Enter lambda value \n') ;
            lambda = powerY ;
            if lambda == 0
                Yp = exp(Yp) ; Ytest = exp(Ytest) ;
            else
                Yp = (lambda*Yp + 1).^(1/lambda) ;
                Ytest = (lambda*Ytest + 1).^(1/lambda) ;
            end
    end
end

