function [trnOut]  = MyscaleData(trn,XtrainMin,XtrainMax)

trnOut  =  2*((trn - repmat(XtrainMin,size(trn,1),1))./(repmat(XtrainMax - XtrainMin,size(trn,1),1))) - 1 ;
indx   = find(isnan(trnOut));
if numel(indx) ~= 0
    trnOut(indx)  = -1;
end

% Testing Verisi Scale Ediliyor
% tstOut  =  2*(tst - repmat(min(trn,[],1),size(tst,1),...
%     1))./(repmat(max(trn,[],1)-min(trn,[],1),size(tst,1),1))-1;
% indx   = find(isnan(tstOut));
% if numel(indx) ~= 0
%     trnOut(indx)  = -1;
% end
end